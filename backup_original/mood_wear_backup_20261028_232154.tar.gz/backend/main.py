from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import sqlite3, hashlib, os
DB=os.path.join(os.path.dirname(__file__),'fashion.db')
app=FastAPI(title='Mood Wear API')
app.add_middleware(CORSMiddleware,allow_origins=['*'],allow_methods=['*'],allow_headers=['*'])
def conn():
 c=sqlite3.connect(DB);c.row_factory=sqlite3.Row;return c
def init():
 with conn() as c:
  c.execute('CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY,name TEXT,price INTEGER,category TEXT,stock INTEGER)')
  c.execute('CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,username TEXT,email TEXT UNIQUE,phone TEXT,password_hash TEXT)')
  c.execute('CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY,user_id INTEGER,address TEXT,total INTEGER,created_at TEXT DEFAULT CURRENT_TIMESTAMP)')
  c.execute('CREATE TABLE IF NOT EXISTS order_items(id INTEGER PRIMARY KEY,order_id INTEGER,product_id INTEGER,quantity INTEGER,size TEXT,color TEXT,unit_price INTEGER)')
  if not c.execute('SELECT COUNT(*) FROM products').fetchone()[0]:
   data=[('Name',2400,'Upper',24),('Denim Jacket',1290,'Upper',15),('Wide Leg Pants',890,'Bottom',40),('Cap',390,'Hat',35),('Sneakers',2200,'Shoes',12),('Necklace',350,'Accessories',50),('Cotton Tee',590,'Upper',40),('Skirt',790,'Bottom',28),('Hoodie',1190,'Upper',16),('Set Name',22400,'Set',6)]
   c.executemany('INSERT INTO products(name,price,category,stock) VALUES(?,?,?,?)',data)
init()
class User(BaseModel):
 username:str;email:str;password:str;phone:str=''
class Login(BaseModel):
 email:str;password:str
class Item(BaseModel):
 product_id:int;quantity:int=1;size:str='M';color:str='Blue'
class Order(BaseModel):
 user_id:int|None=None;address:str;items:list[Item]
def hashed(s):return hashlib.sha256(s.encode()).hexdigest()
@app.get('/products')
def products(category:str|None=None,search:str|None=None):
 sql='SELECT * FROM products WHERE 1=1';args=[]
 if category and category!='New Arrival':sql+=' AND category=?';args.append(category)
 if search:sql+=' AND name LIKE ?';args.append('%'+search+'%')
 with conn() as c:return [dict(r) for r in c.execute(sql,args)]
@app.get('/products/{pid}')
def product(pid:int):
 with conn() as c:r=c.execute('SELECT * FROM products WHERE id=?',(pid,)).fetchone()
 if not r:raise HTTPException(404,'Product not found')
 return dict(r)
@app.post('/register')
def register(u:User):
 if not u.username.strip() or '@' not in u.email or len(u.password)<6:raise HTTPException(400,'Enter username, valid email, password >= 6 characters')
 try:
  with conn() as c:
   cur=c.execute('INSERT INTO users(username,email,phone,password_hash) VALUES(?,?,?,?)',(u.username,u.email.lower(),u.phone,hashed(u.password)))
   return {'id':cur.lastrowid,'username':u.username,'email':u.email}
 except sqlite3.IntegrityError:raise HTTPException(409,'Email already registered')
@app.post('/login')
def login(u:Login):
 with conn() as c:r=c.execute('SELECT id,username,email FROM users WHERE email=? AND password_hash=?',(u.email.lower(),hashed(u.password))).fetchone()
 if not r:raise HTTPException(401,'Invalid credentials')
 return dict(r)
@app.post('/orders')
def order(o:Order):
 if not o.address.strip() or not o.items:raise HTTPException(400,'Address and items required')
 with conn() as c:
  total=0;rows=[]
  for item in o.items:
   p=c.execute('SELECT * FROM products WHERE id=?',(item.product_id,)).fetchone()
   if not p or item.quantity<1 or item.quantity>p['stock']:raise HTTPException(400,'Invalid quantity or insufficient stock')
   total+=p['price']*item.quantity;rows.append((p,item))
  cur=c.execute('INSERT INTO orders(user_id,address,total) VALUES(?,?,?)',(o.user_id,o.address,total));oid=cur.lastrowid
  for p,item in rows:
   c.execute('INSERT INTO order_items(order_id,product_id,quantity,size,color,unit_price) VALUES(?,?,?,?,?,?)',(oid,p['id'],item.quantity,item.size,item.color,p['price']))
   c.execute('UPDATE products SET stock=stock-? WHERE id=?',(item.quantity,p['id']))
 return {'order_id':oid,'subtotal':total,'delivery_fee':0,'total':total}
