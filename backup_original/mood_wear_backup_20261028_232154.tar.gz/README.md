# Mood Wear — Flutter + FastAPI

This folder is the **Mood Wear** VS Code project. It contains Flutter UI source, a FastAPI server and SQLite database. It is not a prebuilt Android APK.

## 1. Open the folder

Unzip `mood_wear_vscode.zip`, then in VS Code select **File → Open Folder… → mood_wear**. Install the **Flutter** and **Dart** VS Code extensions and ensure Flutter SDK is installed (`flutter doctor`).

## 2. Generate Flutter Android/iOS platform folders (one-time)

From the VS Code terminal in this folder run:

```bash
bash setup.sh
```

This runs `flutter create --project-name mood_wear --platforms=android,ios .` and `flutter pub get`, then enables local Android emulator HTTP requests. Do not run `flutter create` in a different folder.

## 3. Start the backend (Terminal 1)

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

API docs: http://127.0.0.1:8000/docs . SQLite database `backend/fashion.db` is created automatically when the server starts.

## 4. Run the Flutter app (Terminal 2)

Start an Android emulator in Android Studio → Device Manager. From the **project root** run:

```bash
flutter devices
flutter run --dart-define=API_URL=http://10.0.2.2:8000
```

For iOS Simulator on a Mac:

```bash
flutter run --dart-define=API_URL=http://127.0.0.1:8000
```

Alternatively choose the matching Mood Wear launch configuration in VS Code and press F5.

## Pages

All Flutter page widgets currently live in `lib/main.dart`: Home, product detail, Style Studio/set detail, Search, Saved, Profile (login/register), category browsing, and Basket. Pages are interactive, including color/size selection, favorites, cart quantities and checkout. Product listings, registration/login and orders communicate with FastAPI. This is a classroom demo: the authentication is not production-ready, cart/favorites are in memory, checkout does not process payments, and images are gray wireframe placeholders.

## Troubleshooting

- If `flutter` is not found, install Flutter SDK and add its `bin` folder to PATH.
- If products don't load, keep Terminal 1 running and check http://127.0.0.1:8000/docs .
- Android emulator uses `10.0.2.2`, **not** `localhost`, to access the Mac's backend.
- This source project was packaged without a local Flutter SDK, so it has not been compiled against your installed Flutter version.
