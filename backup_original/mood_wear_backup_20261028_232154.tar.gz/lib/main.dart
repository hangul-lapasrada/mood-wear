import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// Android emulator: 10.0.2.2. iOS simulator: localhost.
const apiBase =
    String.fromEnvironment('API_URL', defaultValue: 'http://10.0.2.2:8000');
const gray = Color(0xFFD9D9D9);
const darkGray = Color(0xFF999999);
void main() => runApp(const MoodWearApp());

class Product {
  final int id, price, stock;
  final String name, category;
  Product.fromJson(Map<String, dynamic> j)
      : id = j['id'],
        price = j['price'],
        stock = j['stock'],
        name = j['name'],
        category = j['category'];
}

class CartItem {
  final Product product;
  String color, size;
  int quantity;
  bool selected = true;
  CartItem(this.product, this.color, this.size, {this.quantity = 1});
}

class Api {
  static Future<List<Product>> products(
      {String? category, String? search}) async {
    final q = <String, String>{};
    if (category != null && category != 'New Arrival') q['category'] = category;
    if (search != null && search.isNotEmpty) q['search'] = search;
    final uri = Uri.parse('$apiBase/products')
        .replace(queryParameters: q.isEmpty ? null : q);
    final r = await http.get(uri).timeout(const Duration(seconds: 8));
    if (r.statusCode != 200)
      throw Exception('Cannot load products: ${r.statusCode}');
    return (jsonDecode(r.body) as List)
        .map((e) => Product.fromJson(e))
        .toList();
  }

  static Future<Map<String, dynamic>> post(
      String path, Map<String, dynamic> body) async {
    final r = await http
        .post(Uri.parse('$apiBase$path'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode(body))
        .timeout(const Duration(seconds: 8));
    if (r.statusCode >= 400) {
      final j = jsonDecode(r.body);
      throw Exception(j['detail'] ?? 'Request failed');
    }
    return Map<String, dynamic>.from(jsonDecode(r.body));
  }
}

class MoodWearApp extends StatelessWidget {
  const MoodWearApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Mood Wear',
      theme: ThemeData(
          useMaterial3: true,
          scaffoldBackgroundColor: Colors.white,
          colorSchemeSeed: Colors.grey,
          appBarTheme: const AppBarTheme(
              backgroundColor: Colors.white, foregroundColor: Colors.black)),
      home: const ShopShell());
}

class ShopShell extends StatefulWidget {
  const ShopShell({super.key});
  @override
  State<ShopShell> createState() => _ShopShellState();
}

class _ShopShellState extends State<ShopShell> {
  int tab = 0;
  List<Product> products = [];
  bool loading = true;
  String? error;
  final List<CartItem> cart = [];
  final Set<int> saved = {};
  int? userId;
  @override
  void initState() {
    super.initState();
    reload();
  }

  Future<void> reload() async {
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final p = await Api.products();
      if (mounted)
        setState(() {
          products = p;
          loading = false;
        });
    } catch (e) {
      if (mounted)
        setState(() {
          loading = false;
          error = e.toString();
        });
    }
  }

  void message(String text) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  void toggleSave(Product p) {
    setState(() {
      if (!saved.add(p.id)) saved.remove(p.id);
    });
  }

  void add(Product p, String color, String size) {
    setState(() {
      final match = cart
          .where(
              (x) => x.product.id == p.id && x.color == color && x.size == size)
          .toList();
      if (match.isNotEmpty) {
        if (match.first.quantity < p.stock) {
          match.first.quantity++;
        } else {
          message('Only ${p.stock} left');
          return;
        }
      } else {
        cart.add(CartItem(p, color, size));
      }
    });
    message('Added to basket');
  }

  void detail(Product p, {bool set = false}) => Navigator.push(
      context,
      MaterialPageRoute(
          builder: (_) => ProductDetail(
              product: p,
              isSet: set,
              saved: saved.contains(p.id),
              onSave: () => toggleSave(p),
              onAdd: (color, size) => add(p, color, size),
              onBasket: openBasket,
              recommendations: products,
              onProduct: detail)));
  void openBasket() => Navigator.push(
      context,
      MaterialPageRoute(
          builder: (_) => BasketPage(
              cart: cart,
              products: products,
              userId: userId,
              onChanged: () => setState(() {}),
              onProduct: detail)));
  Widget header({bool back = false}) => Padding(
      padding: const EdgeInsets.fromLTRB(12, 18, 12, 8),
      child: Row(children: [
        if (back)
          IconButton(
              onPressed: () => Navigator.pop(context),
              icon: const Icon(Icons.arrow_back)),
        Expanded(
            child: InkWell(
                onTap: () => setState(() => tab = 2),
                child: Container(
                    height: 30,
                    decoration: BoxDecoration(
                        color: gray, borderRadius: BorderRadius.circular(6)),
                    padding: const EdgeInsets.only(left: 8),
                    alignment: Alignment.centerLeft,
                    child: const Icon(Icons.search, size: 19)))),
        IconButton(
            onPressed: () => message('No new notifications'),
            icon: const Icon(Icons.notifications_none)),
        IconButton(
            onPressed: () => setState(() => tab = 4),
            icon: const Icon(Icons.account_circle_outlined)),
        IconButton(
            onPressed: openBasket,
            icon: Badge(
                label: Text('${cart.fold<int>(0, (a, b) => a + b.quantity)}'),
                isLabelVisible: cart.isNotEmpty,
                child: const Icon(Icons.shopping_bag_outlined)))
      ]));
  Widget cards(List<Product> list, {bool horizontal = false}) {
    if (horizontal)
      return SizedBox(
          height: 164,
          child: ListView.separated(
              padding: const EdgeInsets.symmetric(horizontal: 25),
              scrollDirection: Axis.horizontal,
              itemCount: list.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (_, i) => SizedBox(
                  width: 112, child: productCard(list[i], compact: true))));
    return GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        padding: const EdgeInsets.all(20),
        itemCount: list.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 16,
            mainAxisSpacing: 18,
            childAspectRatio: .77),
        itemBuilder: (_, i) => productCard(list[i]));
  }

  Widget productCard(Product p, {bool compact = false}) => InkWell(
      onTap: () => detail(p, set: p.category == 'Set'),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const Expanded(child: Picture()),
        Container(
            color: gray,
            padding: EdgeInsets.all(compact ? 6 : 9),
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(p.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      fontSize: compact ? 12 : 19,
                      fontWeight:
                          compact ? FontWeight.bold : FontWeight.normal)),
              Text('THB: ${p.price}',
                  style: TextStyle(fontSize: compact ? 10 : 13))
            ]))
      ]));
  Widget section(String name, List<Product> list) => Column(children: [
        Padding(
            padding: const EdgeInsets.fromLTRB(29, 16, 22, 7),
            child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(name, style: const TextStyle(fontSize: 20)),
                  TextButton(
                      onPressed: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => Scaffold(
                                  appBar: AppBar(title: Text(name)),
                                  body: cards(list)))),
                      child: const Text('View All',
                          style: TextStyle(color: Colors.black)))
                ])),
        cards(list, horizontal: true)
      ]);
  Widget home() {
    final visible = products.where((p) => p.category != 'Set').toList();
    return ListView(children: [
      header(),
      const Picture(height: 230),
      SizedBox(
          height: 44,
          child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                'New Arrival',
                'Upper',
                'Bottom',
                'Hat',
                'Shoes',
                'Accessories'
              ]
                  .map((c) => TextButton(
                      onPressed: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => CategoryPage(
                                  category: c, onProduct: detail))),
                      child: Text(c,
                          style: const TextStyle(
                              color: Colors.black, fontSize: 12))))
                  .toList())),
      section('Top-Pick', visible.take(6).toList()),
      section('Trending', visible.reversed.take(6).toList()),
      const SizedBox(height: 25),
      InkWell(
          onTap: () => setState(() => tab = 1),
          child: Container(
              color: darkGray,
              padding: const EdgeInsets.all(24),
              child: const Row(children: [
                Expanded(
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                      Text('Style Studio', style: TextStyle(fontSize: 29)),
                      Text('Mix and Match your style'),
                      SizedBox(height: 12),
                      Chip(label: Text('View More'))
                    ])),
                Icon(Icons.image_outlined, size: 70)
              ]))),
      cards(visible.take(6).toList())
    ]);
  }

  Widget studio() {
    final sets = products.where((p) => p.category == 'Set').toList();
    return ListView(children: [
      header(),
      const Padding(
          padding: EdgeInsets.all(18),
          child: Text('Style Studio', style: TextStyle(fontSize: 27))),
      if (sets.isNotEmpty) ...[
        InkWell(
            onTap: () => detail(sets.first, set: true),
            child: const Padding(
                padding: EdgeInsets.all(20),
                child: Picture(height: 350, icon: Icons.checkroom))),
        ListTile(
            title: Text(sets.first.name, style: const TextStyle(fontSize: 30)),
            subtitle: Text('THB ${sets.first.price}'),
            trailing: IconButton(
                onPressed: () => toggleSave(sets.first),
                icon: Icon(saved.contains(sets.first.id)
                    ? Icons.favorite
                    : Icons.favorite_border))),
        Padding(
            padding: const EdgeInsets.all(20),
            child: FilledButton(
                onPressed: () => detail(sets.first, set: true),
                child: const Text('VIEW SET')))
      ],
      const Padding(
          padding: EdgeInsets.all(20),
          child: Text('Recommend', style: TextStyle(fontSize: 20))),
      cards(products.where((p) => p.category != 'Set').take(6).toList())
    ]);
  }

  Widget search() {
    return Column(children: [
      Padding(
          padding: const EdgeInsets.all(18),
          child: TextField(
              decoration: const InputDecoration(
                  prefixIcon: Icon(Icons.search),
                  hintText: 'Search fashion products',
                  border: OutlineInputBorder()),
              onChanged: (s) => setState(() => searchTerm = s))),
      Expanded(
          child: ListView(children: [
        cards(products
            .where(
                (p) => p.name.toLowerCase().contains(searchTerm.toLowerCase()))
            .toList())
      ]))
    ]);
  }

  String searchTerm = '';
  Widget profile() => ProfilePage(
      onLoggedIn: (id) => setState(() => userId = id), userId: userId);
  @override
  Widget build(BuildContext context) => Scaffold(
      body: SafeArea(
          child: loading
              ? const Center(child: CircularProgressIndicator())
              : error != null
                  ? Center(
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                      Text(error!, textAlign: TextAlign.center),
                      ElevatedButton(
                          onPressed: reload, child: const Text('Retry'))
                    ]))
                  : IndexedStack(index: tab, children: [
                      home(),
                      studio(),
                      search(),
                      ListView(children: [
                        const Padding(
                            padding: EdgeInsets.all(20),
                            child:
                                Text('Saved', style: TextStyle(fontSize: 26))),
                        cards(products
                            .where((p) => saved.contains(p.id))
                            .toList())
                      ]),
                      profile()
                    ])),
      bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          currentIndex: tab,
          onTap: (i) => setState(() => tab = i),
          selectedItemColor: Colors.black,
          unselectedItemColor: Colors.black,
          items: const [
            BottomNavigationBarItem(
                icon: Icon(Icons.home_outlined), label: 'Home'),
            BottomNavigationBarItem(
                icon: Icon(Icons.checkroom_outlined), label: 'Style Studio'),
            BottomNavigationBarItem(icon: Icon(Icons.search), label: 'Search'),
            BottomNavigationBarItem(
                icon: Icon(Icons.favorite_border), label: 'Saved'),
            BottomNavigationBarItem(
                icon: Icon(Icons.account_circle_outlined), label: 'Profile')
          ]));
}

class Picture extends StatelessWidget {
  final double? height;
  final IconData icon;
  const Picture({super.key, this.height, this.icon = Icons.image_outlined});
  @override
  Widget build(BuildContext context) => Container(
      height: height,
      color: darkGray,
      alignment: Alignment.center,
      child: Icon(icon, size: height != null ? 60 : 45, color: Colors.black));
}

class CategoryPage extends StatefulWidget {
  final String category;
  final void Function(Product, {bool set}) onProduct;
  const CategoryPage(
      {super.key, required this.category, required this.onProduct});
  @override
  State<CategoryPage> createState() => _CategoryPageState();
}

class _CategoryPageState extends State<CategoryPage> {
  late Future<List<Product>> future;
  @override
  void initState() {
    super.initState();
    future = Api.products(category: widget.category);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
      appBar: AppBar(title: Text(widget.category)),
      body: FutureBuilder<List<Product>>(
          future: future,
          builder: (context, s) {
            if (!s.hasData)
              return Center(
                  child: Text(s.hasError ? '${s.error}' : 'Loading...'));
            return GridView.builder(
                padding: const EdgeInsets.all(18),
                itemCount: s.data!.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    mainAxisSpacing: 15,
                    crossAxisSpacing: 15,
                    childAspectRatio: .78),
                itemBuilder: (_, i) {
                  final p = s.data![i];
                  return InkWell(
                      onTap: () =>
                          widget.onProduct(p, set: p.category == 'Set'),
                      child: Column(children: [
                        const Expanded(child: Picture()),
                        Container(
                            color: gray,
                            width: double.infinity,
                            padding: const EdgeInsets.all(8),
                            child: Text('${p.name}\nTHB ${p.price}'))
                      ]));
                });
          }));
}

class ProductDetail extends StatefulWidget {
  final Product product;
  final bool isSet, saved;
  final VoidCallback onSave, onBasket;
  final void Function(String, String) onAdd;
  final List<Product> recommendations;
  final void Function(Product, {bool set}) onProduct;
  const ProductDetail(
      {super.key,
      required this.product,
      required this.isSet,
      required this.saved,
      required this.onSave,
      required this.onAdd,
      required this.onBasket,
      required this.recommendations,
      required this.onProduct});
  @override
  State<ProductDetail> createState() => _ProductDetailState();
}

class _ProductDetailState extends State<ProductDetail> {
  String color = 'Blue', size = 'XS';
  bool favorite = false;
  int picture = 0;
  @override
  void initState() {
    super.initState();
    favorite = widget.saved;
  }

  @override
  Widget build(BuildContext context) {
    final p = widget.product;
    return Scaffold(
        appBar: AppBar(title: const Text(''), actions: [
          IconButton(
              onPressed: widget.onBasket,
              icon: const Icon(Icons.shopping_bag_outlined)),
          IconButton(
              onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) => Scaffold(
                          appBar: AppBar(title: const Text('Profile')),
                          body: const Center(
                              child: Text(
                                  'Open Profile from the bottom navigation'))))),
              icon: const Icon(Icons.account_circle_outlined))
        ]),
        body: ListView(
          children: [
            Padding(
                padding: const EdgeInsets.all(19),
                child: Picture(
                    height: widget.isSet ? 430 : 210,
                    icon:
                        widget.isSet ? Icons.checkroom : Icons.image_outlined)),
            if (!widget.isSet)
              SizedBox(
                  height: 65,
                  child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: 4,
                      itemBuilder: (_, i) => InkWell(
                          onTap: () => setState(() => picture = i),
                          child: Container(
                              width: 78,
                              margin: const EdgeInsets.only(left: 18),
                              decoration: BoxDecoration(
                                  border: Border.all(
                                      color: picture == i
                                          ? Colors.black
                                          : Colors.transparent)),
                              child: const Picture())))),
            Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(children: [
                  Expanded(
                      child:
                          Text(p.name, style: const TextStyle(fontSize: 32))),
                  IconButton(
                      onPressed: () {
                        widget.onSave();
                        setState(() => favorite = !favorite);
                      },
                      icon: Icon(
                          favorite ? Icons.favorite : Icons.favorite_border))
                ])),
            if (!widget.isSet)
              const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20),
                  child: Text('★★★★★   5.0 (230 Review)')),
            Padding(
                padding: const EdgeInsets.all(22),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('Price'),
                            Text('THB ${p.price}',
                                style: const TextStyle(fontSize: 20))
                          ]),
                      Text('${p.stock} Left',
                          style: const TextStyle(fontSize: 19))
                    ])),
            const Divider(thickness: 10, color: gray),
            if (!widget.isSet) ...[
              const Padding(
                  padding: EdgeInsets.fromLTRB(20, 20, 20, 6),
                  child: Text('Color')),
              SizedBox(
                  height: 118,
                  child: ListView(
                      scrollDirection: Axis.horizontal,
                      children: ['Blue', 'Orange', 'Yellow', 'Red']
                          .map((c) => InkWell(
                              onTap: () => setState(() => color = c),
                              child: Container(
                                  width: 105,
                                  margin: const EdgeInsets.only(left: 12),
                                  decoration: BoxDecoration(
                                      border: Border.all(
                                          color: color == c
                                              ? Colors.black
                                              : Colors.transparent)),
                                  child: Column(children: [
                                    Expanded(
                                        child: Container(
                                            color: {
                                      'Blue': const Color(0xFF383838),
                                      'Orange': const Color(0xFFCCCCCC),
                                      'Yellow': const Color(0xFFF0F0F0),
                                      'Red': const Color(0xFF555555)
                                    }[c])),
                                    Container(
                                        color: gray,
                                        width: double.infinity,
                                        padding: const EdgeInsets.all(6),
                                        child: Text(c))
                                  ]))))
                          .toList())),
              const Padding(padding: EdgeInsets.all(20), child: Text('Size')),
              Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  child: GridView.count(
                      crossAxisCount: 4,
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      mainAxisSpacing: 12,
                      crossAxisSpacing: 9,
                      childAspectRatio: 1,
                      children: [
                        'XXS',
                        'XS',
                        'S',
                        'M',
                        'L',
                        'XL',
                        'XXL',
                        'XXXL'
                      ]
                          .map((s) => InkWell(
                              onTap: () => setState(() => size = s),
                              child: Container(
                                  alignment: Alignment.center,
                                  decoration: BoxDecoration(
                                      color: gray,
                                      border: Border.all(
                                          color: size == s
                                              ? Colors.black
                                              : Colors.grey,
                                          width: size == s ? 2 : 1)),
                                  child: Text(s))))
                          .toList())),
              const Divider(height: 45, thickness: 10, color: gray),
              const Padding(
                  padding: EdgeInsets.all(22),
                  child: Text(
                      'Product Description\n\nA versatile fashion piece for everyday styling. Select your preferred color and size before adding it to your basket.\n\nMix and match this item with other pieces from our collection.',
                      style: TextStyle(fontSize: 15, height: 1.6)))
            ],
            if (widget.isSet) ...[
              const Divider(thickness: 10, color: gray),
              const Padding(
                  padding: EdgeInsets.all(20),
                  child: Text('Recommend', style: TextStyle(fontSize: 19))),
              Padding(
                  padding: const EdgeInsets.all(18),
                  child: GridView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: widget.recommendations
                          .where((x) => x.category != 'Set')
                          .take(6)
                          .length,
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 2,
                              crossAxisSpacing: 16,
                              mainAxisSpacing: 16,
                              childAspectRatio: .8),
                      itemBuilder: (_, i) {
                        final r = widget.recommendations
                            .where((x) => x.category != 'Set')
                            .elementAt(i);
                        return InkWell(
                            onTap: () => widget.onProduct(r),
                            child: Column(children: [
                              const Expanded(child: Picture()),
                              Container(
                                  width: double.infinity,
                                  color: gray,
                                  padding: const EdgeInsets.all(8),
                                  child: Text('${r.name}\nTHB ${r.price}'))
                            ]));
                      }))
            ]
          ],
        ),
        bottomNavigationBar: SafeArea(
            child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(children: [
                  Expanded(
                      child: OutlinedButton(
                          onPressed: () => widget.onAdd(color, size),
                          child: const Text('PUT IN BASKET'))),
                  const SizedBox(width: 24),
                  Expanded(
                      child: FilledButton(
                          style: FilledButton.styleFrom(
                              backgroundColor: const Color(0xFF444444)),
                          onPressed: () {
                            widget.onAdd(color, size);
                            widget.onBasket();
                          },
                          child: const Text('BUY NOW')))
                ]))));
  }
}

class ProfilePage extends StatefulWidget {
  final void Function(int) onLoggedIn;
  final int? userId;
  const ProfilePage(
      {super.key, required this.onLoggedIn, required this.userId});
  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  bool register = false, busy = false;
  final username = TextEditingController(),
      email = TextEditingController(),
      phone = TextEditingController(),
      password = TextEditingController(),
      confirm = TextEditingController();
  @override
  void dispose() {
    for (final c in [username, email, phone, password, confirm]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> submit() async {
    if (register && password.text != confirm.text) {
      show('Passwords do not match');
      return;
    }
    setState(() => busy = true);
    try {
      final r = await Api.post(
          register ? '/register' : '/login',
          register
              ? {
                  'username': username.text,
                  'email': email.text,
                  'phone': phone.text,
                  'password': password.text
                }
              : {'email': email.text, 'password': password.text});
      widget.onLoggedIn(r['id']);
      show(register ? 'Registration successful' : 'Logged in successfully');
    } catch (e) {
      show(e.toString());
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  void show(String t) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));
  Widget field(String label, TextEditingController controller,
          {bool secret = false}) =>
      Padding(
          padding: const EdgeInsets.only(bottom: 17),
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(label, style: const TextStyle(fontSize: 19)),
            const SizedBox(height: 5),
            TextField(
                controller: controller,
                obscureText: secret,
                decoration: InputDecoration(
                    hintText: 'Enter $label',
                    filled: true,
                    fillColor: gray,
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(6),
                        borderSide: BorderSide.none),
                    isDense: true))
          ]));
  @override
  Widget build(BuildContext context) => ListView(children: [
        const Padding(
            padding: EdgeInsets.all(18),
            child:
                Center(child: Text('Profile', style: TextStyle(fontSize: 18)))),
        const SizedBox(height: 35),
        const Icon(Icons.account_circle_outlined, size: 90),
        if (widget.userId != null)
          const Padding(
              padding: EdgeInsets.all(20),
              child: Center(child: Text('Logged in'))),
        Padding(
            padding: const EdgeInsets.fromLTRB(47, 45, 47, 20),
            child: Column(children: [
              if (register) field('Username', username),
              field('Email', email),
              if (register) field('Phone Number', phone),
              field('Password', password, secret: true),
              if (register) field('Confirm Password', confirm, secret: true),
              SizedBox(
                  width: 160,
                  child: FilledButton(
                      style: FilledButton.styleFrom(
                          backgroundColor: const Color(0xFF444444)),
                      onPressed: busy ? null : submit,
                      child: Text(register ? 'Register' : 'Login'))),
              TextButton(
                  onPressed: () => setState(() => register = !register),
                  child: Text(
                      register ? 'Already Have Account?' : 'New? Register',
                      style: const TextStyle(color: Colors.grey)))
            ]))
      ]);
}

class BasketPage extends StatefulWidget {
  final List<CartItem> cart;
  final List<Product> products;
  final int? userId;
  final VoidCallback onChanged;
  final void Function(Product, {bool set}) onProduct;
  const BasketPage(
      {super.key,
      required this.cart,
      required this.products,
      required this.userId,
      required this.onChanged,
      required this.onProduct});
  @override
  State<BasketPage> createState() => _BasketPageState();
}

class _BasketPageState extends State<BasketPage> {
  final address = TextEditingController();
  bool busy = false;
  @override
  void dispose() {
    address.dispose();
    super.dispose();
  }

  int get subtotal => widget.cart
      .where((e) => e.selected)
      .fold(0, (s, e) => s + e.product.price * e.quantity);
  void update() {
    setState(() {});
    widget.onChanged();
  }

  Future<void> checkout() async {
    final selected = widget.cart.where((e) => e.selected).toList();
    if (selected.isEmpty || address.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Select items and enter an address')));
      return;
    }
    setState(() => busy = true);
    try {
      final result = await Api.post('/orders', {
        'user_id': widget.userId,
        'address': address.text,
        'items': selected
            .map((e) => {
                  'product_id': e.product.id,
                  'quantity': e.quantity,
                  'size': e.size,
                  'color': e.color
                })
            .toList()
      });
      widget.cart.removeWhere((e) => e.selected);
      update();
      if (mounted)
        showDialog(
            context: context,
            builder: (_) => AlertDialog(
                    title: const Text('Order placed'),
                    content: Text(
                        'Order #${result['order_id']}\nTotal THB ${result['total']}'),
                    actions: [
                      TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: const Text('OK'))
                    ]));
    } catch (e) {
      if (mounted)
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('$e')));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
      appBar: AppBar(title: const Text('Basket'), centerTitle: true),
      body: ListView(children: [
        Container(
            color: gray,
            padding: const EdgeInsets.all(6),
            child: Column(
                children: widget.cart
                    .map((e) => Container(
                        color: Colors.white,
                        margin: const EdgeInsets.only(bottom: 12),
                        padding: const EdgeInsets.all(8),
                        child: Row(children: [
                          const SizedBox(
                              width: 90, height: 85, child: Picture()),
                          const SizedBox(width: 8),
                          Expanded(
                              child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                Text(e.product.name,
                                    style: const TextStyle(fontSize: 24)),
                                Text(e.color),
                                Text('${e.product.price} THB   ${e.size}'),
                                Row(children: [
                                  IconButton(
                                      onPressed: () {
                                        if (e.quantity > 1) {
                                          e.quantity--;
                                          update();
                                        }
                                      },
                                      icon: const Icon(
                                          Icons.remove_circle_outline)),
                                  Text('${e.quantity}'),
                                  IconButton(
                                      onPressed: () {
                                        if (e.quantity < e.product.stock) {
                                          e.quantity++;
                                          update();
                                        }
                                      },
                                      icon:
                                          const Icon(Icons.add_circle_outline))
                                ])
                              ])),
                          Column(children: [
                            Checkbox(
                                value: e.selected,
                                onChanged: (v) {
                                  e.selected = v ?? false;
                                  update();
                                }),
                            IconButton(
                                onPressed: () {
                                  widget.cart.remove(e);
                                  update();
                                },
                                icon: const Icon(Icons.delete_outline))
                          ])
                        ])))
                    .toList())),
        Padding(
            padding: const EdgeInsets.all(18),
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Basket', style: TextStyle(fontSize: 24)),
              const SizedBox(height: 20),
              Text(
                  'Subtotal                                       $subtotal THB'),
              const Text(
                  'Delivery fee                                      0 THB'),
              Text(
                  'Total price                                      $subtotal THB'),
              const SizedBox(height: 20),
              TextField(
                  controller: address,
                  decoration: const InputDecoration(
                      labelText: 'Location / Address',
                      hintText: 'Enter delivery address',
                      border: OutlineInputBorder())),
              const SizedBox(height: 20),
              Row(children: [
                Expanded(
                    child: OutlinedButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text('Continue Shopping'))),
                const SizedBox(width: 15),
                Expanded(
                    child: FilledButton(
                        style: FilledButton.styleFrom(
                            backgroundColor: const Color(0xFF444444)),
                        onPressed: busy ? null : checkout,
                        child: const Text('Checkout')))
              ])
            ])),
        const Divider(thickness: 12, color: gray),
        const Padding(
            padding: EdgeInsets.all(20),
            child: Text('Similar product', style: TextStyle(fontSize: 19))),
        GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            padding: const EdgeInsets.all(20),
            itemCount: widget.products
                .where((p) => p.category != 'Set')
                .take(6)
                .length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 16,
                mainAxisSpacing: 18,
                childAspectRatio: .8),
            itemBuilder: (_, i) {
              final p = widget.products
                  .where((p) => p.category != 'Set')
                  .elementAt(i);
              return InkWell(
                  onTap: () => widget.onProduct(p),
                  child: Column(children: [
                    const Expanded(child: Picture()),
                    Container(
                        width: double.infinity,
                        color: gray,
                        padding: const EdgeInsets.all(8),
                        child: Text('${p.name}\nTHB ${p.price}'))
                  ]));
            })
      ]));
}
